import time

params_dqn = {
    "base_dir": "${gym_env.env_name}/dqn-S${algorithm.seed}_${current_time:}",
    # `collect_stats` is True: we keep the cumulated reward for all
    # evaluation episodes
    "collect_stats": True,
    "save_best": True,
    "algorithm": {
        "seed": 2,
        "max_grad_norm": 1,
        "epsilon": 0.05,
        "n_envs": 8,
        "n_steps": 64,
        "n_updates": 64,
        "eval_interval": 10_000,
        "learning_starts": 5_000,
        "nb_evals": 7,
        "buffer_size": 20_000,
        "batch_size": 256,
        "target_critic_update": 1_000,
        "max_epochs": 206,
        "discount_factor": 0.99,
        "architecture": {"hidden_size": [128, 256, 512]},
    },
    "gym_env": {
        "env_name": "supertuxkart/flattened_multidiscrete-v0",
    },
    "optimizer": {
        "classname": "torch.optim.Adam",
        "lr": 1e-3,
    },
}

params_ddpg = {
    "save_best": False,
    "base_dir": "${gym_env.env_name}/ddpg-S${algorithm.seed}_${current_time:}",
    "collect_stats": True,
    # Set to true to have an insight on the learned policy
    # (but slows down the evaluation a lot!)
    "plot_agents": False,
    "algorithm": {
        "seed": 2,
        "max_grad_norm": 1,
        "epsilon": 0.02,
        "n_envs": 8,
        "n_steps": 100,
        "nb_evals": 7,
        "discount_factor": 0.98,
        "buffer_size": 2e5,
        "batch_size": 64,
        "tau_target": 0.05,
        "eval_interval": 10_000,
        "max_epochs": 250,
        # Minimum number of transitions before learning starts
        "learning_starts": 10000,
        "action_noise": 0.1,
        "architecture": {
            "actor_hidden_size": [128, 64, 32],
            "critic_hidden_size": [128, 64, 32],
        },
    },
    "gym_env": {
        "env_name": "supertuxkart/flattened_continuous_actions-v0",
    },
    "actor_optimizer": {
        "classname": "torch.optim.Adam",
        "lr": 1e-3,
    },
    "critic_optimizer": {
        "classname": "torch.optim.Adam",
        "lr": 1e-3,
    },
}

params_td3 = {
    "save_best": False,
    "base_dir": "${gym_env.env_name}/td3-S${algorithm.seed}_${current_time:}",
    "collect_stats": False,
    # Set to true to have an insight on the learned policy
    # (but slows down the evaluation a lot!)
    "plot_agents": False,
    "pretraining": True,
    "algorithm": {
        "seed": 1,
        "max_grad_norm": 0.5,
        "epsilon": 0.02,
        "n_envs": 4,
        "n_steps": 25,
        "nb_evals": 7,
        "discount_factor": 0.98,
        "buffer_size": 1e6, #1e6
        "batch_size": 256,
        "tau_target": 0.05,
        "eval_interval": 100_000,
        "max_epochs": 1500,
        # Minimum number of transitions before learning starts
        "learning_starts": 10_000,
        "action_noise": 0.1,
        "architecture": {
            "actor_hidden_size": [400, 300],
            "critic_hidden_size": [400, 300],
        },
    },
    "gym_env": {
        "env_name": "supertuxkart/flattened_continuous_actions-v0",
    },
    "actor_optimizer": {
        "classname": "torch.optim.Adam",
        "lr": 1e-3,
    },
    "critic_optimizer": {
        "classname": "torch.optim.Adam",
        "lr": 1e-3,
    },
}

params_SAC = {
    "save_best": True,
    "base_dir": "${gym_env.env_name}/sac-S${algorithm.seed}_${current_time:}",
    "algorithm": {
        "seed": 1,
        "n_envs": 8,
        "n_steps": 32,
        "buffer_size": 1e6, #20%
        "batch_size": 256,
        "max_grad_norm": 0.5, #0.5
        "nb_evals": 7, #7
        "eval_interval": 100_000, #20 000
        "learning_starts": 1_000, #10 000
        "max_epochs": 500, #250
        "discount_factor": 0.99,
        "entropy_mode": "auto",  # "auto" or "fixed"
        "init_entropy_coef": 0.001,
        "tau_target": 0.01,
        "architecture": {
            "actor_hidden_size": [256, 256],
            "critic_hidden_size": [256, 256],
        },
    },
    "gym_env": {"env_name": "supertuxkart/flattened_continuous_actions-v0"},
    "actor_optimizer": {
        "classname": "torch.optim.Adam",
        "lr": 3e-4,
    },
    "critic_optimizer": {
        "classname": "torch.optim.Adam",
        "lr": 3e-4, #3e-4
    },
    "entropy_coef_optimizer": {
        "classname": "torch.optim.Adam",
        "lr": 3e-4,
    },
}

params_ppo = {
    "base_dir": "${gym_env.env_name}/ppo-clip-S${algorithm.seed}_${current_time:}",
     "save_best": False,
    "logger": {
        "classname": "bbrl.utils.logger.TFLogger",
        "cache_size": 10000,
        "every_n_seconds": 10,
        "verbose": False,
    },
    "pretraining": True,
    "load_model": False,
    "algorithm": {
        "seed": 12,
        "max_grad_norm": 0.5,
        "n_envs": 4,
        "n_steps": 128,
        "eval_interval": 200_000,
        "nb_evals": 16,
        "gae": 0.95,
        "discount_factor": 0.98,
        "normalize_advantage": True,
        "max_epochs": 5_000,
        "opt_epochs": 10,
        "batch_size": 256,
        "clip_range": 0.2,
        "clip_range_vf": 0.2,
        "entropy_coef": 1e-4, #2e-7
        "policy_coef": 1,
        "critic_coef": 0.5,
        "policy_type": "DiscretePolicy",
        "architecture": {
            "actor_hidden_size": [256, 256, 256],
            "critic_hidden_size": [256, 256, 256],
        },
    },
    "gym_env": {
        "env_name": "supertuxkart/flattened_discrete-v0"
    },
    "optimizer": {
        "classname": "torch.optim.AdamW",
        "lr": 3e-4,
        "eps": 1e-5,
    },
}

params_TQC={
  "save_best": False,
  "logger":{
    "classname": "bbrl.utils.logger.TFLogger",
    "log_dir": "./tblogs/" + str(time.time()),
    "cache_size": 10000,
    "every_n_seconds": 10,
    "verbose": False,    
    },
  
  "pretraining": True,
  "load_model" : False,
  
  "algorithm":{
    "seed": 1,
    "n_envs": 2,
    "n_steps": 256,
    "n_updates": 10,
    "buffer_size": 1e6,
    "batch_size": 256,
    "max_grad_norm": 0.5,
    "nb_evals": 16,
    "eval_steps" : 500,
    "eval_interval": 200_000,
    "learning_starts": 10_000,
    "max_epochs": 4000, #1000
    "discount_factor": 0.98,
    "entropy_coef": 1e-7, #1e-5
    "target_entropy": "auto",
    "tau_target": 0.05,
    "top_quantiles_to_drop": 2,
    "architecture":{
      "actor_hidden_size": [64, 64],
      "critic_hidden_size": [512, 512], #[256, 256]
      "n_nets": 2,
      "n_quantiles": 25,
    },
  },
  "gym_env":{
    "classname": "__main__.make_gym_env",
    "env_name": "supertuxkart/flattened_continuous_actions-v0",
    },
  "actor_optimizer":{
    "classname": "torch.optim.Adam",
    "lr": 1e-3, #1e-3
    },
  "critic_optimizer":{
    "classname": "torch.optim.Adam",
    "lr": 1e-3, #1e-3
    },
  "entropy_coef_optimizer":{
    "classname": "torch.optim.Adam",
    "lr": 1e-3, #1e-3
    }
}